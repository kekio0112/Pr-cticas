
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author seegio ivan piñon peña
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
        System.out.println("INTRODUCE TU CALIFICACION :v");
        int iCalifa;
        
        iCalifa = input.nextInt();
        if (iCalifa == 100) {
            
        System.out.println("Tienes una A");
        } else 
        if (iCalifa == 90) {
        System.out.println("tienes una B");
        } else 
        if (iCalifa == 80) {
        System.out.println("tienes una C");
        } else 
        if (iCalifa == 70) {
        System.out.println("tienes una D");
        } else 
        if (iCalifa == 60) {
        System.out.println("tienes una F");
        } else {
        System.out.println("Calificacion fuera de rango");
                     
    }

    }
    
}
