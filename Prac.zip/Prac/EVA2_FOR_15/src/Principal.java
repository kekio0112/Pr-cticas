
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SERGIO IVAN PIÑON PEÑA
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Dame un numero entero positivo");
        int iNum = input.nextInt();
        boolean bPrimo =true;
        for (int i = 2; i< iNum; i++) {
            if ((iNum % i)== 0) {
                bPrimo = false ;
                break;
            }
        }
        if (bPrimo) {
            System.out.println("Es primo");
        }else{
            System.out.println("No es primo");
        }
    }
    
}
