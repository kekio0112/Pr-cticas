
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sergio ivan piñon peña 
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Dame las 5 edades");
        int iSumasEdades = 0;
        System.out.println("Edad 1:");
        iSumasEdades = iSumasEdades + input.nextInt();
        System.out.println("Edad 2:");
        iSumasEdades += input.nextInt();
        System.out.println("Edad 3:");
        iSumasEdades = iSumasEdades + input.nextInt();
        System.out.println("Edad 4:");
        iSumasEdades += input.nextInt();
        System.out.println("Edad 5:");
         iSumasEdades = iSumasEdades + input.nextInt();
         double dMedia = (double) iSumasEdades / 5;
         System.out.println("La media es: " + dMedia);
    }
    
}
