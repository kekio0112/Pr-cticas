/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_for_2;

import java.util.Scanner;

/**
 *
 * @author sergio ivan piñon peña
 */
public class EVA2_FOR_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Dame tu nombre");
        String sNom;
        sNom = input.nextLine();
        System.out.println("Dime el numero de veces que quieras imprimirlo");
        int j;
        j = input.nextInt();
        for (int i=1; i <= j; i++) {
            System.out.println(i + "-" + sNom);
        }
    }
    
}
