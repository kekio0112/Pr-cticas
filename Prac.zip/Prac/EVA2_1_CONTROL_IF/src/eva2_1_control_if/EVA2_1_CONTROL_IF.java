/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_1_control_if;

import java.util.Scanner;

/**
 *
 * @author IVAN PIÑON PEÑA
 */
public class EVA2_1_CONTROL_IF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Dame tu califa de programa");
        double iCali;
                iCali = input.nextDouble();
                System.out.println("Tu calificasion es: "+ iCali);
                if (iCali >=70) {
                     System.out.println("Pasate progra");
                } else {
                    System.out.println("Lo bueno es que ahí salud");
                }
                   
                
    }
    
}
