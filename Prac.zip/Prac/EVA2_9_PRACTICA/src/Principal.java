
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        int iA, iB, iC ;
        System.out.println("Introduce A");
        iA = input.nextInt();
        System.out.println("Introduce B");
        iB = input.nextInt(); 
        System.out.println("Introduce C");
        iC = input.nextInt();
        
        int iDisc = (iB *iB) - (4 * iA * iC);
        
        boolean bBan =false ;
        if (iDisc == 0);
        
 
    }
    
}
