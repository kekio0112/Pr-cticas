/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_9;

import java.util.Scanner;

/**
 *
 * @author temporal2
 */
public class EVA2_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingresa un numero");
        
        System.out.println("Valor 1");
        int num = input.nextInt();
        System.out.println("Valor 2");
        int num2 = input.nextInt();
        
        double result;
        result = (double)num / num2;
        
        System.out.println("Resultado = " + result);
        
        if(result == 0)
            System.out.println("Numero par");
        else
            System.out.println("Numero impar");
        
        int resud = num % num2;
        
        
        System.out.println("Residuo = " + resud);
    
    
        
    }
    
}
