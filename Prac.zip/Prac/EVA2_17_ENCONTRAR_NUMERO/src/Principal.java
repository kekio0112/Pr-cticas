
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sergio ivan piñon peña
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int iNumeAlea = (int)(Math.random() * 10) +1;
        //System.out.println(iNumeAlea);
        for (int i = 0 ; i < 3; i++) {
            System.out.println("Adivina un nuemro");
            int iNume = input.nextInt();
            if(iNume == iNumeAlea) {
                System.out.println("Felicidades , ganaste");
            }
            if (i == 2) {              
              System.out.println("Lo bueno es que ahí salud");
            }
        }
        int j=1;
        if (j==1) {
            System.out.println("1");
        } else {
            System.out.println("2");
        }
           System.out.println("3");
    }
    
}
