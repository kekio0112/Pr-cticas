/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_for_5;

import java.util.Scanner;

/**
 *
 * @author SERGIO IVAN PIÑON PEÑA
 */
public class EVA2_FOR_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        for (int i =100; i <=300; i++) {
            System.out.println("-" + i);
        }
    }
    
}
