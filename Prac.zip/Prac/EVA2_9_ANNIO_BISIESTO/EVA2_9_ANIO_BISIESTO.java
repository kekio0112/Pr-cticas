/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_2_9_anio_bisiesto;

import java.util.Scanner;

/**
 *
 * @author temporal2
 */
public class EVA2_2_9_ANIO_BISIESTO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Introducir un año");
        
        int annio = input.nextInt();
        
        if ((annio % 4 == 0) && ((annio % 100 != 0) && (annio % 400 == 0)))
            System.out.println("Año Bisiesto");
        
        else System.out.println("Año no Bisiesto");
        
    }
    
}
