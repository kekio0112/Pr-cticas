/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_for_6;

import java.util.Scanner;

/**
 *
 * @author SERGIO IVAN PIÑON PEÑA
 */
public class EVA2_FOR_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        for (int i =0; i <=100; i+=5) {
            System.out.println("-" + i);
        }
    }
    
}
