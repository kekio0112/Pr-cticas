
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sergio ivan piñon peña
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        for (int i=100; i >=1; i--) {
            System.out.println(i);
        }
        for (int i=100; i >=1; i--) {
            System.out.print(i + "-");
        }
    }
    
}
