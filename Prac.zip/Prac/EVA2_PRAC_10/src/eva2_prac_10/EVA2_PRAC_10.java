/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_prac_10;

import java.util.Scanner;

/**
 *
 * @author temporal2
 */
public class EVA2_PRAC_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        int iMate, iFis, iQuim;
        System.out.println("Introduce A");
        iMate = input.nextInt();
        System.out.println("Introdudce B");
        iFis = input.nextInt();
        System.out.println("Introduce C");
        iQuim = input.nextInt();
        
        
        int  iSuma = iMate + iFis + iQuim;
        
        if(((iMate >= 65) && (iFis >= 55) &&
                (iQuim >= 50)) && (iSuma >= 180))
             
            (((iMate >= 65) && (iSuma >= 140)))        
        System.out.println("ACEPTADO");
        
                
        
    }
    }
    
}
