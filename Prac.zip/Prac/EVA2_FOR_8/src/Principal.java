
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SERGIO IVAN PIÑON PEÑA
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        
         for (int i = 0 ; i <= 20; i++) {
             int iNumeAlea = (int)(Math.random() * 100) +1;
             System.out.println( i +"-  "+iNumeAlea);
        }
    }
    
}
