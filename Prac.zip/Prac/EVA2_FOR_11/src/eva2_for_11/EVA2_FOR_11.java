/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_for_11;

import java.util.Scanner;

/**
 *
 * @author SERGIO IVAN PIÑON PEÑA
 */
public class EVA2_FOR_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        System.out.println("Dame un nuemro entero");
        int iNum;
        iNum= input.nextInt();
        for (int i=1; i<=100; i+=iNum)
            System.out.println("-"+i);
    }
    
}
